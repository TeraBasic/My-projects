import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

public class Leader {
	// variable comsomateur
	private ArrayList<String> messageComso;
	private int nbMessConso,nbCell;
	
	public static ReentrantLock pingLock = new ReentrantLock(), 
			electionLock = new ReentrantLock();
	private static boolean isLeader = false, isPing = true;
	public static Process leaderDetector;

	public static Process getElectionDetector() {
		return leaderDetector;
	}

	public static void setElectionDetector(Process leaderDetector) {
		Leader.leaderDetector = leaderDetector;
	}
	/*
	 * si le processu est encore connecté
	 */
	public static boolean isPingFlag() {
		return isPing;
	}
	/**
	 * 
	 * @param pingFlag
	 */
	public static void setPingFlag(boolean pingFlag) {
		Leader.isPing = pingFlag;
	}
	/**
	 * si le processu est leader
	 * @return
	 */
	public static boolean isLeaderFlag() {
		return isLeader;
	}

	public static void setLeaderFlag(boolean leaderFlag) {
		Leader.isLeader = leaderFlag;
	}
	/**
	 * initialiser les processus
	 * @param t
	 */
	public static void initialElection(MyThread[] t) {
		Process temp = new Process(-1);
		for (int i = 0; i < t.length; i++)
			if (temp.getPid() < t[i].getProcess().getPid())
				temp = t[i].getProcess();
		
		t[temp.pid - 1].getProcess().isCoordinator = true;
	}
}