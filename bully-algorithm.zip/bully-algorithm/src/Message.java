import java.io.Serializable;

public class Message implements Serializable {

	enum Type {
		DEMANDE_ELECTION, CONFIRMATION_ELECTION
	}
	
	private final int author;
	private final Type type;
	private final String content;
	private final int clock;
	
	public Message(int author, Type type, String content, int clock) {
		super();
		this.author = author;
		this.type = type;
		this.content = content;
		this.clock = clock;
	}
	
	public int getAuthor() {
		return author;
	}
	
	public Type getType() {
		return type;
	}

	public String getContent() {
		return content;
	}

	public int getClock() {
		return clock;
	}
	
	@Override
	public String toString() {
		return "{origine=" + author + "; horloge=" + clock + "; message=\"" + content + "\"; type=" + type + "}";
	}
}
